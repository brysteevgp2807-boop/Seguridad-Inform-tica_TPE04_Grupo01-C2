# Laboratorio SQL Injection — Flask + SQLite

Proyecto académico local para Visual Studio Code. Requiere Python 3.10+.

## Instalar en Windows PowerShell
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```
Si PowerShell bloquea la activación, usa CMD: `.venv\Scripts\activate.bat`.
Abre http://127.0.0.1:5000

## Usuarios ficticios
- admin / Admin123!
- carlos / Clase123!
- luly / Prueba123!

## Rutas
- `/login-vulnerable`, `/login-seguro`
- `/buscar-vulnerable`, `/buscar-seguro`
- `/panel` requiere sesión
- `/prueba-xss` muestra salida escapada por Jinja

## Pruebas controladas (solo localhost)
En el login vulnerable, usuario: `' OR '1'='1' -- ` y cualquier contraseña. Repite en el login seguro: debe denegar. En búsqueda vulnerable, prueba: `%' OR 1=1 -- `; compara con la búsqueda segura.

## Nmap
Instala Nmap desde https://nmap.org/download.html. Con Flask activo, en otra terminal ejecuta `nmap -sV -p 5000 127.0.0.1`. Escanea únicamente tu propio equipo.

## Seguridad
Las rutas vulnerables son intencionales para el aprendizaje y no deben publicarse. El servidor solo escucha en 127.0.0.1. Los datos son ficticios. Las contraseñas se guardan en texto plano solo para aislar la demostración SQLi; producción requiere Argon2id/bcrypt, CSRF, HTTPS, secretos seguros, control de intentos y mínimos privilegios.

La base `laboratorio.db` se crea al iniciar. Para reiniciarla, detén Flask y elimina ese archivo. `.gitignore` evita subirla junto con el entorno virtual.
