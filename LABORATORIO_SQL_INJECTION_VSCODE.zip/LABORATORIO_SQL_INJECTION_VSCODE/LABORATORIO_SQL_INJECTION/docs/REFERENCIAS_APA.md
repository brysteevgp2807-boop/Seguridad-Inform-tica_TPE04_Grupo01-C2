# Referencias APA 7
- OWASP Foundation. (s. f.). *SQL Injection Prevention Cheat Sheet*. https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html
- OWASP Foundation. (s. f.). *OWASP Top 10*. https://owasp.org/www-project-top-ten/
- Pallets Projects. (s. f.). *Flask Documentation*. https://flask.palletsprojects.com/
- SQLite. (s. f.). *SQLite Documentation*. https://www.sqlite.org/docs.html
- Nmap Project. (s. f.). *Nmap Reference Guide*. https://nmap.org/book/man.html
- Python Software Foundation. (s. f.). *Python 3 Documentation*. https://docs.python.org/3/
