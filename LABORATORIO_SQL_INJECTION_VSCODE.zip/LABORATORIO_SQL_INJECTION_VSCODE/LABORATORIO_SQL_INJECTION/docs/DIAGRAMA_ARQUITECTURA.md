# Arquitectura
```mermaid
flowchart TD
 A[Usuario / navegador] -->|HTTP localhost:5000| B[Servidor Flask]
 B --> C{Ruta}
 C -->|Login y búsqueda vulnerable| D[SQL concatenado - laboratorio]
 C -->|Login y búsqueda segura| E[SQL parametrizado]
 D --> F[(SQLite: datos ficticios)]
 E --> F
 B --> G[Plantillas HTML y CSS]
 G --> A
```
Descripción en 4 líneas: el usuario envía formularios desde el navegador local; Flask recibe solicitudes y ejecuta la lógica; las rutas vulnerables y seguras consultan la misma base con técnicas distintas; el navegador muestra los resultados para comparar riesgo y mitigación.
