# Guía paso a paso según la tarea S11

## 3.1 Herramientas
Python ejecuta la lógica; Flask crea el servidor; SQLite almacena los datos; VS Code permite editar; Git/GitHub versiona y comparte el código.

## 3.2.1 Servidor Flask y SQLite
1. Abre la carpeta en VS Code. 2. Crea el entorno virtual e instala dependencias. 3. Ejecuta `python app.py`. 4. Abre `http://127.0.0.1:5000`. La base y los datos ficticios se crean automáticamente. Captura el explorador de VS Code, terminal y página inicial.

## 3.2.2 Demostración SQL Injection
1. Abre `/login-vulnerable`. 2. En usuario escribe `' OR '1'='1' -- ` y cualquier contraseña. 3. Observa el acceso concedido de la demostración. 4. Abre `/buscar-vulnerable` y busca `%' OR 1=1 -- `. 5. Observa que la consulta concatenada puede devolver todos los productos. Captura formularios, consultas y resultados. Solo en localhost.

## 3.2.3 Refactorización y contramedida
La versión insegura concatena datos con una f-string. La versión segura usa marcadores `?` y envía los valores aparte: `conn.execute(sql, (usuario, clave))`. Repite las entradas en `/login-seguro` y `/buscar-seguro`: la entrada se interpreta como dato y no cambia el SQL. Captura el código antes/después y resultados.

## 3.2.4 Escaneo de red y seguridad
Instala Nmap desde https://nmap.org/download.html. Con Flask activo ejecuta `nmap -sV -p 5000 127.0.0.1` en otra terminal. Captura el resultado. Para WLAN describe WPA2-AES/WPA3, clave robusta, firmware actualizado, WPS desactivado y red de invitados. Para bases de datos describe consultas parametrizadas, mínimo privilegio, copias de seguridad, hash de contraseñas y control de acceso.

## 3.3 Manual y pruebas
Instalación: `py -m venv .venv`, activar, `python -m pip install -r requirements.txt`. Ejecución: `python app.py`. Antes de mitigar: prueba rutas vulnerables. Después: repite en rutas seguras. `/panel` sin sesión devuelve 403; inicia sesión seguro con `admin / Admin123!` y prueba otra vez.

## 3.4 Resultados
Registra resultados reales. Códigos: 200 respuesta correcta, 302 redirección, 403 prohibido, 404 no encontrado, 500 error interno. Tabla sugerida: inicio GET 200; login seguro válido 200; login seguro con payload denegado 200; panel sin sesión 403; XSS mostrado como texto 200. No inventes observaciones.

## Capturas mínimas
1. Estructura de archivos. 2. Terminal con Flask. 3. Página inicial. 4. Login vulnerable. 5. Búsqueda vulnerable. 6. Código parametrizado. 7. Login seguro denegado. 8. Búsqueda segura. 9. Nmap localhost. 10. Panel 403 y panel con sesión.

## Explicación oral de Carlos (3.2.3)
“Identifiqué que la consulta vulnerable concatenaba directamente los datos ingresados. La corregí mediante consultas parametrizadas con marcadores de posición. Así SQLite recibe por separado la instrucción y los valores, evitando que una entrada manipulada cambie la estructura SQL. Repetí la prueba en la versión segura y comprobé que no permite eludir la autenticación.”

## Precaución
La aplicación es una maqueta educativa. No desplegar en Internet. Para producción se requieren contraseñas con hash seguro, CSRF, HTTPS, secretos adecuados, limitación de intentos y revisión de seguridad.
